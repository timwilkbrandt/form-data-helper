﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IFrameTest
{
    /// <summary>
    /// Summary description for IFrameTestHandler
    /// </summary>
    public class IFrameTestHandler : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {

            var temp = context.Request.Form["key1"];
            var file = context.Request.Files["Photo"];
            context.Response.ContentType = "text/plain";


            context.Response.Write("Hello World");
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}