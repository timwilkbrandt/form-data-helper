/*jslint browser:true */
/*global tryConsoleLog*/

(function () {

    'use strict';

    function tryConsoleLog(data) {

        var isDebug = true; //for production set to false

        try { if (isDebug) { console.log(data); } } catch (ignore) {//not supported by this browser version
        }
    }
	
    var formDataHelper = formDataHelper ||  = {

        settings: {
            //Form Default Propertie 
            target: '',
            enctype: 'multipart/form-data',
            action: '',
            method: 'Post',
        },

		//parameters: [{"key":<someKey>, "val":<someval>},...]
        createFormData: function (parameters, files, createNewForm) {

	
			var formEle = null;
			
			if(createNewForm)
			{		
				formEle = document.createElement('Form');
				
				Array.prototype.forEach.call(files, function (file, i) {
					formEle.appendChild(file[0]);
				});
			}
			else
			{
				formEle = document.forms[0];
			}
		
            formEle.setAttribute('action', formDataHelper.settings.action);
            formEle.setAttribute('method', formDataHelper.settings.method);
            formEle.setAttribute('target', formDataHelper.settings.target);
            formEle.setAttribute('enctype', formDataHelper.settings.enctype);
            
			        
               
            Array.prototype.forEach.call(parameters, function (parameter, i) {

                var inputEle = document.createElement("input");
                inputEle.setAttribute("type", "hidden");
                inputEle.setAttribute("name", parameter.key);
                inputEle.setAttribute("value", parameter.val);

                var targetEle = document.querySelectorAll('input[name="' + inputEle.name + '"]');
                if (targetEle.length > 0) {
                    document.forms[0].removeChild(targetEle[0]);
                }

                document.forms[0].appendChild(inputEle);

            });

        },

        createIframe: function (frameId, callback) {

            //If no callback is passed in we will use the default one here.
            if (callback == null) { callback = formDataHelper.iframeCallback; }

            var frame;

			var targetFrame = document.getElementById(formDataHelper.settings.target);
			
            if (frameId == null && targetFrame.length <= 0) {

                frame = document.createElement('IFRAME');
                frame.name = formDataHelper.settings.target;
                frame.id = formDataHelper.settings.target;
                frame.width = 0;
                frame.height = 0;
                frame.style.display = 'none';

                document.forms[0].insertBefore(frame, document.forms[0].firstChild);
            }
            else {
                frame = document.getElementById(frameId);
            }

            frame.removeEventListener('load', callback);
            frame.addEventListener('load', callback);
        },

        iframeCallback: function (data) {

            tryConsoleLog(data);

        },

        submitFormData: function () {

            //if jquery validation needs to be removed
            //$(document.forms[0]).validate().settings.ignore = "*"; 
            document.forms[0].submit();
        }

    };

}());



/*Sample implementation*/

formDataHelper.settings.action = '/same/endpoint'
formDataHelper.settings.target = 'formDataUpload';

var parameters = [];
var param1 = { "key": "foo1", "val": "foo1" };
var param2 = { "key": "foo2", "val": "foo2"};
parameters.push(param1);
parameters.push(param2);

formDataHelper.createFormData(parameters, null);
formDataHelper.createIframe(null, myCutomIframeCallBack);
formDataHelper.submitFormData();

myCutomIframeCallBack: function(){alert('finished!');}: