﻿/// <reference path="FormDataModule.js" />
var main = main || {};


main.core = {

    parameters:null,

    init: function () {

        main.core.createParameters();
        


        $('#targetButton').click(function () {
            var files = $('#testFile');
            formDataHelper.module.settings.target = 'formDataUpload';
            formDataHelper.module.settings.action = '/IFrameTestHandler.ashx';
            formDataHelper.module.createFormData(main.core.parameters, null, false);
            formDataHelper.module.createIframe('formDataUpload', main.core.mainCallback);
            formDataHelper.module.submitFormData();
        });
    },

    createParameters: function () {

        main.core.parameters = [];

        var paramter1 = { "key": "key1", "val": "val1" };
        var paramter2 = { "key": "key2", "val": 1 };

        main.core.parameters.push(paramter1);
        main.core.parameters.push(paramter2);

    },

    mainCallback: function (response) { alert('in main callback!'); console.log(response);}
};

$(document).ready(function () {
    main.core.init();
});